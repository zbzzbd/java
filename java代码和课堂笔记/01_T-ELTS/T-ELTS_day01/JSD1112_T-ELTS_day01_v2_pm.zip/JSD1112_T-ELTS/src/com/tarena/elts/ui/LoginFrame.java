package com.tarena.elts.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class LoginFrame extends JFrame {
  public LoginFrame() {
    init();
  }
  /** ��ʼ��, ��¼�����е�����Ͳ��� */
  private void init(){
    setTitle("��¼����ϵͳ");
    setSize(300, 220);
    setContentPane(createContentPane());
  }
  private JPanel createContentPane(){
    JPanel p = new JPanel(new BorderLayout());
    p.setBorder(new EmptyBorder(8,8,8,8));
    p.add(BorderLayout.NORTH, 
        new JLabel("��¼ϵͳ",JLabel.CENTER));
    p.add(BorderLayout.CENTER, createCenterPane());
    p.add(BorderLayout.SOUTH, createBottomPane());
    return p;
  }
  private JPanel createCenterPane(){
    JPanel p = new JPanel(new BorderLayout());
    p.setBorder(new EmptyBorder(10,0,0,0));
    p.add(BorderLayout.NORTH, createIdPwdPane());
    return p;
  }
  private JPanel createIdPwdPane(){
    JPanel p = new JPanel(new GridLayout(2,1,0,6));
    p.add(createIdPane());
    p.add(createPwdPane());
    return p;
  }
  private JPanel createIdPane(){
    JPanel p = new JPanel(new BorderLayout());
    p.add(BorderLayout.WEST, new JLabel("���:"));
    JTextField idField = new JTextField();
    p.add(BorderLayout.CENTER, idField);
    return p;
  }
  private JPanel createPwdPane(){
    JPanel p = new JPanel(new BorderLayout());
    p.add(BorderLayout.WEST, new JLabel("����:"));
    JPasswordField pwdField = new JPasswordField();
    pwdField.enableInputMethods(true);//Linux bug
    p.add(BorderLayout.CENTER, pwdField);
    return p;
  }

  private JPanel createBottomPane(){
    JPanel p = new JPanel(new FlowLayout());
    JButton login = new JButton("��¼");
    JButton cancel = new JButton("ȡ��");
    p.add(login);
    p.add(cancel);
    return p;
  }
}










