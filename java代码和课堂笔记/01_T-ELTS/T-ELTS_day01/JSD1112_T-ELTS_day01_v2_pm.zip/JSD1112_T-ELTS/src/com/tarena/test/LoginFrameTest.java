package com.tarena.test;

import com.tarena.elts.ui.LoginFrame;

public class LoginFrameTest {
  public static void main(String[] args) {
    LoginFrame frame = new LoginFrame();
    frame.setVisible(true);
  }

}
