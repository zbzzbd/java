package javase2.day01;

public class PrintFileDemo {
  public static void main(String[] args) {
    String file = "d:/myclient.zip";
    IOUtils.print(file);
  }

}
