package javase2.day02;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/** Card �˿���ʵ����IO ��ʾ */
public class CardIODemo {
  public static void main(String[] args) 
    throws IOException {
    //��һ���˿��ƴ洢���ļ���, Ҳ�����˿��Ƶĳ־ô洢.
    List<Card> cards = new ArrayList<Card>();
    for(int rank=Card.THREE; rank<=Card.DEUCE;rank++){
      cards.add(new Card(Card.DIAMOND, rank));
      cards.add(new Card(Card.SPADE, rank));
      cards.add(new Card(Card.HEART, rank));
      cards.add(new Card(Card.CLUB, rank));
    }
    cards.add(new Card(Card.JOKER, Card.BLACK));
    cards.add(new Card(Card.JOKER, Card.COLOR));
    Collections.shuffle(cards);
    String file = "cards.dat";  
    DataOutputStream out = new DataOutputStream(
        new BufferedOutputStream(
            new FileOutputStream(file)));
//    for(Iterator<Card> i=cards.iterator();i.hasNext();){
//      Card card = i.next();
//    }
    for(Card card:cards){
      out.writeInt(card.getSuit());
      out.writeInt(card.getRank());
    }
    out.close();
    System.out.println(cards); 
    IOUtils.print(file);
  }
}
